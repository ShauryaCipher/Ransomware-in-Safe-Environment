#!/bin/bash
# Installation script for the Educational Ransomware Simulation Tool

echo "=========================================================="
echo "  Installing dependencies for Ransomware Simulation Tool  "
echo "=========================================================="
echo ""
echo "This will install the required Python packages."
echo ""

# Check if Python is installed
if command -v python3 &>/dev/null; then
    PYTHON_CMD="python3"
elif command -v python &>/dev/null; then
    PYTHON_CMD="python"
else
    echo "Error: Python not found. Please install Python 3.6+ before continuing."
    exit 1
fi

# Check Python version
$PYTHON_CMD -c "import sys; exit(0) if sys.version_info >= (3, 6) else exit(1)" || {
    echo "Error: Python 3.6 or higher is required."
    exit 1
}

echo "Using Python: $($PYTHON_CMD --version)"
echo ""

# Install required packages
echo "Installing required packages..."
$PYTHON_CMD -m pip install -r requirements.txt

echo ""
echo "Installation complete!"
echo ""
echo "To run the simulator:"
echo "  $PYTHON_CMD ransomware_simulation_desktop.py --interactive"
echo ""
echo "For help and options:"
echo "  $PYTHON_CMD ransomware_simulation_desktop.py --help"
echo ""